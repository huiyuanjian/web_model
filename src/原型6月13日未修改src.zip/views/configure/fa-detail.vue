<template>
    <div class="warp-main">
        <Card>
            <h4 class="title-h4"  slot="title">
                <Icon type="ios-paper-outline"></Icon> 分发接口详情
            </h4>
            <Row style="margin-bottom: 10px;">
                <Col span="24">
                  
                    <Input  placeholder="搜索物联网接口名称" style="width: 200px" />
                    <Input  placeholder="搜索IOServer名称" style="width: 200px" />
                     <Select  style="width:120px;text-align:left" placeholder="请选择类型" v-model="search_status">
                        <Option v-for="item in search_status_list" :value="item.value" :key="item.value">{{ item.label }}</Option>
                    </Select>
                    <Input  placeholder="搜索设备或数据包名称" style="width: 200px" />
                    <Input  placeholder="变量名称" style="width: 200px" />
                 
                    <Button type="primary" size="large">查询</Button>
                    <Button type="default" size="large">清空</Button>
                </Col>
                <!-- <Col  span="12" style="text-align: right">
                    <Button type="primary" size="large"><Icon type="ios-add"></Icon> 新增</Button>
                </Col> -->
            </Row>
            <Row :gutter="10">
                <Col span="24">
                    <Table border :columns="InternetTit" :data="InternetData"></Table>
                    <Page class="page-position" :current="pageIndex" :total="totalItemCount" show-total :page-size='pageSize'></Page>
                </Col>
            </Row>
        </Card>
    </div>
</template>

<script>

import {distributiondetailsTit, distributiondetailsData} from '../datas/tableData.js';
export default {
    name: '',
    data () {
        return {
            InternetTit: distributiondetailsTit,
            InternetData: distributiondetailsData,
            pageIndex: 1,
            totalItemCount: 0,
            pageSize: 2,
            search_status: '',
            search_status_list: [
                { value: 0, label:'数据包'},
                { value: 1, label:'设备'}
            ],
        };
    },
    mounted () {
        this.totalItemCount =   this.InternetData.length
    }
};
</script>
