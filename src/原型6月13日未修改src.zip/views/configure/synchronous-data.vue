
<template>
    <div class="warp-main">
        <Card>
            <h4 class="title-h4"  slot="title">
                <Icon type="ios-paper-outline"></Icon> 同步数据
            </h4>
            <Row>
                <Col span="6" >
                    <Card style="width:calc(100% - 15px);height: 600px;">
                        <p slot="title">
                            采集分组
                        </p>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Input v-model="search.tree_name" icon="search" placeholder="输入关键字" style="width: 100%" />
                            </Col>
                        </Row>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <my-tree 
                                :list="tree.treeList" 
                                :isRightAction="true" 
                                :parentAction="tree.parentAction" 
                                :childAction="tree.childAction" 
                                :form='modalForm'
                                :modalFormValidate='modalFormValidate'
                                @fun='synchroData'
                                style="width: 100%" ></my-tree>
                            </Col>
                        </Row>
                    </Card>
                </Col>
                <Col span="18">
                    <Card style="width:calc(100% - 15px);height: 600px;margin-left: 7px;">
                        <p slot="title">
                           设备
                        </p>
                        <div v-if="synchro_loading" style="position:absolute;width: 95%;height: 80%;">
                            <Spin fix>
                                <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
                                <div>正在同步，请稍等。。。</div>
                            </Spin>
                        </div>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Input icon="search" placeholder="设备名称" style="width: 100%" />
                            </Col>
                        </Row>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <div class="bb-box" style="margin-bottom: 10px;text-align: center;">
                                    <Button type="primary" size="large" >全量启用</Button>
                                    <Button type="primary" size="large" >全量停用</Button>
                                    <Button type="primary" size="large" >启用</Button>
                                    <Button type="primary" size="large" >停用</Button>
                                </div>
                                <Table border :columns="[]" :data="[]"></Table>
                                <Page class="page-position" :current="page.pageIndex" :total="page.totalItemCount" show-total :page-size='page.pageSize'></Page>
                            </Col>
                        </Row>
                    </Card>
                </Col>
            </Row>
        </Card>
    </div>
</template>

<script>
import {InternetData, InternetTit} from '../datas/tableData.js';
import myTree from '../main-components/tree/my-tree.vue';
export default {
    components: {
        myTree
    },
    name: '',
    data () {
        return {
            page: {
                pageIndex: 1,
                totalItemCount: 100,
                pageSize: 50
            },
            tree: {
                parentAction: [
                    {title:'添加Ioserver',registerFuntion: 'addObj'}
                ],
                childAction: [
                    {
                        title: '同步设备和变量',
                        registerFuntion: 'fun'
                    },
                    {
                        title: '修改',
                        registerFuntion: 'updObj'
                    },
                    {
                        title: '删除',
                        registerFuntion: 'delObj'
                    }
                ],
                treeList: [
                    {
                        id: 1,
                        parentID: 0,
                        title: '物联网接口1',
                        isSelected: true,
                        isActionShow: true,
                        isHover: false,
                        children: [
                            {
                                id: 10001,
                                parentID: 1,
                                title: 'IOServer1',
                                isSelected: false,
                                isActionShow: false,
                                isHover: false
                            },
                            {
                                id: 10002,
                                parentID: 1,
                                title: 'IOServer1',
                                isSelected: false,
                                isActionShow: false,
                                isHover: false
                            }
                        ]
                    },  {
                        id: 2,
                        parentID: 0,
                        title: '物联网接口2',
                        isSelected: false,
                        isActionShow: false,
                        isHover: false,
                        children: [
                            {
                                id: 20001,
                                parentID: 2,
                                title: 'IOServer21',
                                isSelected: false,
                                isActionShow: false,
                                isHover: false
                            },
                            {
                                id: 20002,
                                parentID: 2,
                                title: 'IOServer21',
                                isSelected: false,
                                isActionShow: false,
                                isHover: false
                            }
                        ]
                    }
                ]
            },
            search: {
                tree_name: ''
            },
            modalForm: [
                {
                    name: 'IOServer名称',
                    key: 'name',
                    classParent: 'form-row',
                    inputType: 'text'
                }, {
                    name: 'IP和端口号',
                    key: 'ipAndPost',
                    classParent: 'form-row-inputs',
                    inputType: 'text',
                }, {
                    name: '采集周期',
                    key: 'acquisitionCycle',
                    classParent: 'form-row',
                    inputType: 'text'
                }, {
                    name: '描述',
                    key: 'describe',
                    classParent: 'form-row',
                    inputType: 'textarea',
                    limits: {minRows: 2,maxRows: 5}
                }
            ],
            modalFormValidate: {
                name: [
                    { required: true, message: '请输入名称', trigger: 'blur' }
                ],
                ipAndPost: [
                    { required: true, message: '请输入Ip和端口号', trigger: 'blur' }
                ],
                acquisitionCycle: [
                    { required: true, message: '请输入采集周期', trigger: 'blur'}
                ]
            },
            synchro_loading: false
        };
    },
    mounted () {
    },
    methods: {
        synchroData (data) {
            this.synchro_loading = true
            setTimeout(() => {
                this.synchro_loading = false
            }, 1000)
        }
    }
};
</script>
<style>
.tree-row{
    position: relative;
    display: inline-block;
    width: calc(100% - 17px);
    height: 28px;
    line-height: 28px;
    padding-left: 5px;
    box-sizing: border-box;
}
.tree-row > a{
    position: absolute;
    right: 0;
    top: 0;
    width: 20px;
    height: 100%;
    text-align: center;
}
.tree-action-box{
    position: absolute;
    top: 0;
    left: calc(100%);
    border: 1px solid #ccc;
    border-bottom:  none;
    width: 120px;
    line-height: 30px;
    z-index: 999;
    background: #fff;
    font-size: 13px;
}
.tree-action-box a {
    display: block;
    padding: 0 10px;
    border-bottom: 1px solid #ccc;
}
.demo-spin-icon-load{
    animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
    from { transform: rotate(0deg);}
    50%  { transform: rotate(180deg);}
    to   { transform: rotate(360deg);}
}
.demo-spin-col{
    height: 100px;
    position: relative;
    border: 1px solid #eee;
}
/* .tree-row-selected a{
    display: block;
} */
</style>
