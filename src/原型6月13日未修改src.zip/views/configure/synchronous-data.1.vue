
<template>
    <div class="warp-main">
        <Card>
            <h4 class="title-h4"  slot="title">
                <Icon type="ios-paper-outline"></Icon> 同步数据
            </h4>
            <Row>
                <Col span="6" >
                    <Card style="width:calc(100% - 15px);height: 600px;">
                        <p slot="title">
                            采集分组
                        </p>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <!-- <Select  style="width:45%;text-align:left" placeholder="请选择" v-model="search_status">
                                    <Option v-for="item in ['物联网接口1','物联网接口2']" :value="item" :key="item">{{ item }}</Option>
                                </Select> -->
                                <Input icon="search" placeholder="输入关键字" style="width: 100%" />
                            </Col>
                        </Row>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <my-tree 
                                :list="treeList" 
                                :isRightAction="true" 
                                :parentAction="parentAction" 
                                :childAction="childAction" 
                                @onAddIos='addIos'
                                style="width: 100%" ></my-tree>
                            </Col>
                        </Row>
                    </Card>
                </Col>
                 <Col span="7">
                    <Card style="width:calc(100% - 15px);height: 600px;margin-left: 7px;">
                        <p slot="title">
                           设备
                        </p>
                        <div v-if="showLoding" style="position:absolute;width: 95%;height: 80%;">
                            <Spin fix>
                                <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
                                <div>正在同步，请稍等。。。</div>
                            </Spin>
                        </div>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Input icon="search" placeholder="设备名称" style="width: 100%" />
                            </Col>
                        </Row>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <div class="bb-box" style="margin-bottom: 10px;text-align: center;">
                                    <Button type="primary" size="large" >全量启用</Button>
                                    <Button type="primary" size="large" >全量停用</Button>
                                    <Button type="primary" size="large" >启用</Button>
                                    <Button type="primary" size="large" >停用</Button>
                                </div>
                                <Table border :columns="InternetTit" :data="InternetData"></Table>
                                <Page class="page-position" :current="pageIndex" :total="totalItemCount" show-total :page-size='pageSize'></Page>
                            </Col>
                        </Row>
                    </Card>
                </Col>
                 <Col span="11">
                    <Card style="width:calc(100% - 15px);height: 600px;margin-left: 15px;positon:relative">

                        <p slot="title">
                            设备信息
                        </p>
                        <div v-if="showLoding" style="position:absolute;width: 98%;height: 80%;">
                            <Spin fix>
                                <Icon type="load-c" size=18 class="demo-spin-icon-load"></Icon>
                                <div>正在同步，请稍等。。。</div>
                            </Spin>
                        </div>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <!-- <div style="border-bottom: 1px solid #ccc;margin-bottom: 5px;">设备信息</div> -->
                                 <Form  class="d-form"
                                
                                    :label-width="100" 
                                    label-position="right"
                              
                                >
                                    <FormItem label="ID：" >
                                        32
                                    </FormItem>
                                     <FormItem label="名称：" >
                                        水位监测设备1
                                    </FormItem>
                                    <!-- <FormItem label="采集周期：" >
                                        <div style="display:inline-block;width:100%;">
                                            <Input></Input>
                                        </div>
                                    </FormItem> -->
                                </Form>
                              
                            </Col>
                        </Row>
                        <div style="border-bottom: 1px solid #ccc;margin-bottom: 15px;"></div>
                          <!-- <div class="bb-box" style="margin: 10px 0;text-align: center;">
                                <Button type="primary" size="large" >变量启用</Button>
                                <Button type="primary" size="large" >变量停用</Button>
                            </div> -->
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Table border :columns="InternetTit2" :data="InternetData2"></Table>
                                <Page class="page-position" :current="pageIndex" :total="totalItemCount" show-total :page-size='pageSize'></Page>
                            </Col>
                        </Row>
                    </Card>
                </Col>
            </Row>
            <Modal v-model="addModal" :closable='false' :mask-closable=false :width="500">
                <h3 slot="header" style="color:#2D8CF0">{{modal.title}}</h3>

                <div slot="footer">
                    <Button type="text" @click="cancelEditPass">取消</Button>
                    <Button type="primary" :loading="savePassLoading" @click="saveEditPass">保存</Button>
                </div>
            </Modal>
        </Card>
    </div>
</template>

<script>
import {InternetData, InternetTit} from '../datas/tableData.js';
import myTree from '../main-components/tree/my-tree.vue';
export default {
    components: {
        myTree
    },
    name: '',
    data () {
        return {
            parentAction: [
                {title:'添加Ioserver',registerFuntion:'onAddIos'}
            ],
            childAction:[
                {
                    title: '同步设备和变量',
                    registerFuntion: ''
                },
                {
                    title: '修改',
                    registerFuntion: ''
                },
                {
                    title: '删除',
                    registerFuntion: ''
                }
            ],
            showLoding: false,
            search_status: '',
            InternetTit: [
            {
                type: 'selection',
                width: 45,
                align: 'center'
            },{
                key:'name',
                title: '设备名称'
            }],
            InternetData: [{
                name: '设备名称1'
            }],
            InternetTit2: [{
                key:'name',
                title: '变量名称'
            },{
                key:'txt',
                title: '变量描述'
            },{
                key:'txt1',
                title: '顺序号'
            },{
                key:'ID',
                title: 'ID'
            }
            ],
            InternetData2: [{
                name: '变量1',
                txt: '变量描述',
                txt1: '125',
                ID: 1
            }],
            pageIndex: 1,
            totalItemCount: 0,
            pageSize: 2,
            treeList: [{
                id: 1,
                parentID: 0,
                title: '物联网接口1',
                expand: true,
                isSelected: true,
                isActionShow: false,
                isHover: false,
                children: [
                    {
                        title: 'IOServer1',
                        expand: true,
                        isSelected: false,
                        isActionShow: false,
                        isHover: false,
                    
                    },
                    {
                        title: 'IOServer1',
                        expand: true,
                        isSelected: false,
                        isActionShow: false,
                        isHover: false,
                        render: (h, { root, node, data }) => {
                            let actionType = [
                                h('a',{
                                    on: {
                                        click: () => {
                                            event.cancelBubble = true
                                            data.isActionShow = false
                                            this.showLoding = true
                                            setTimeout(()=>{
                                                this.showLoding = false
                                            }, 2000)
                                        }
                                    }
                                }, '同步设备和变量'),
                                h('a',{
                                    on: {
                                        click: () => {
                                            event.cancelBubble = true
                                            this.$router.push({
                                                name: 'ioserver-add',
                                                query:{
                                                    type: 'upd'
                                                }
                                            })
                                        }
                                    }
                                }, '修改'),
                                h('a',{
                                    on: {
                                        click: () => {
                                            event.cancelBubble = true
                                            this.$Modal.confirm({
                                                title: '操作提示',
                                                content: '删除后将不可恢复，您确定要删除该信息吗？',
                                                onOk: () => {
                                                    this.$Message.success('删除成功！！');
                                                },
                                                onCancel: () => {
                                                }
                                            });
                                        }
                                    }
                                }, '删除')
                            ]
                            let icon = h('Icon', {
                                props: {
                                    type: 'ios-paper-outline'
                                },
                                style: {
                                    marginRight: '8px'
                                }
                            })
                            return  this.setRender(h, data, icon, actionType) 
                        }
                    }
                ]
            }, {
                id: 2,
                parentID: 0,
                title: '物联网接口2',
                expand: true,
                isSelected: false,
                isActionShow: false,
                isHover: false,
                render: (h, { root, node, data }) => {
                     let actionType = [
                         h('a',{
                             on: {
                                 click: () => {
                                    event.cancelBubble = true
                                    this.$router.push({name: 'ioserver-add'})
                                 }
                             }
                        }, '添加Ioserver'),
                         h('a',{
                             on: {
                                 click: () => {
                                    event.cancelBubble = true
                                    this.$router.push({
                                        name: 'interface-add',
                                        query:{
                                            type: 'upd'
                                        }
                                    })
                                 }
                             }
                         }, '修改'),
                          h('a',{
                             on: {
                                 click: () => {
                                    event.cancelBubble = true
                                    this.$Modal.confirm({
                                        title: '操作提示',
                                        content: '删除后将不可恢复，您确定要删除该信息吗？',
                                        onOk: () => {
                                            this.$Message.success('删除成功！！');
                                        },
                                        onCancel: () => {
                                        }
                                    });
                                 }
                             }
                         }, '删除')
                    ]
                    let icon = h('Icon', {
                        props: {
                            type: 'ios-folder-outline'
                        },
                        style: {
                            marginRight: '8px'
                        }
                    })
                    return  this.setRender(h, data, icon) 
                },
                children: []
            }],
            searchList: [{
                id: '1',
                name: '物联网接口1',
                expand: true,
                showAction: false,
                isEdit: false,
                actionList:[{
                    actionName: '添加IOServer',
                    link: 'ioserver-add',
                    actionFlag: 'url'
                },{
                    actionName: '详情',
                    link: 'ioserver-add',
                    actionFlag: 'url'
                },{
                    actionName: '修改',
                    link: 'ioserver-add',
                    actionFlag: 'url'
                },{
                    actionName: '删除',
                    link: 'ioserver-add',
                    actionFlag: 'url'
                }],
                children: [
                    {
                        id: '3',
                        name: 'IOServer1',
                        showAction: false,
                        isEdit: false,
                        actionList:[{
                            actionName: '同步设备和变量',
                            link: 'ioserver-add',
                            actionFlag: 'function'
                        },{
                            actionName: '详情',
                            link: 'ioserver-add',
                            actionFlag: 'function'
                        },{
                            actionName: '修改',
                            link: 'ioserver-add',
                            actionFlag: 'function'
                        },{
                            actionName: '删除',
                            link: 'ioserver-add',
                            actionFlag: 'function'
                        }]
                    }
                ]
            }]
        };
    },
    mounted () {
        this.totalItemCount = this.InternetData.length
    },
    methods: {
        addIos (data) {
            console.log(data)
        }
    }
};
</script>
<style>
.tree-row{
    position: relative;
    display: inline-block;
    width: calc(100% - 17px);
    height: 28px;
    line-height: 28px;
    padding-left: 5px;
    box-sizing: border-box;
}
.tree-row > a{
    position: absolute;
    right: 0;
    top: 0;
    width: 20px;
    height: 100%;
    text-align: center;
}
.tree-action-box{
    position: absolute;
    top: 0;
    left: calc(100%);
    border: 1px solid #ccc;
    border-bottom:  none;
    width: 120px;
    line-height: 30px;
    z-index: 999;
    background: #fff;
    font-size: 13px;
}
.tree-action-box a {
    display: block;
    padding: 0 10px;
    border-bottom: 1px solid #ccc;
}
.demo-spin-icon-load{
    animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
    from { transform: rotate(0deg);}
    50%  { transform: rotate(180deg);}
    to   { transform: rotate(360deg);}
}
.demo-spin-col{
    height: 100px;
    position: relative;
    border: 1px solid #eee;
}
/* .tree-row-selected a{
    display: block;
} */
</style>
