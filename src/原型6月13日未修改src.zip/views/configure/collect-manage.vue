
<template>
    <div class="warp-main">
        <Card>
            <h4 class="title-h4"  slot="title">
                <Icon type="ios-paper-outline"></Icon> 采集管理
            </h4>
            <Row>
                <Col span="6">
                    <Card style="width:calc(100% - 15px);height: 600px;">
                        <p slot="title">
                            模型分组
                        </p>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Input icon="search" placeholder="输入关键字" style="width: 100%" />
                            </Col>
                        </Row>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Tree :data="searchList"></Tree>
                            </Col>
                        </Row>
                    </Card>
                </Col>
                 <Col span="6">
                    <Card style="width:calc(100% - 15px);height: 600px;margin-left: 7px;">
                        <p slot="title">
                           模型的设备与数据包
                        </p>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Input icon="search" placeholder="请输入设备或数据包名称" style="width: 100%" />
                            </Col>
                        </Row>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                            <div style="margin-bottom: 10px;text-align: center;position:relative">
                                <Tabs active-key="key1"  type="card" style="margin-top: 5px;">
                                    <Tab-pane label="设备" key="key1">
                                            <!-- <div style="margin-bottom: 10px;">
                                            <Button type="primary" style="width: 100px;" @click="editPasswordModal = true">新增</Button>
                                            <Button type="success" style="width: 100px;"  @click="updPasswordModal = true">修改</Button>
                                            <Button type="error" style="width: 100px;"  @click="saveEdit">删除</Button>
                                        </div> -->
                                        <Table border :columns="InternetTit" :data="InternetData"></Table>
                                        <Page class="page-position" :current="pageIndex" :total="totalItemCount" show-total :page-size='pageSize'></Page>
                                    </Tab-pane>
                                    <Tab-pane label="数据包" key="key2">
                                        <!-- <div style="margin-bottom: 10px;">
                                            <Button type="primary" style="width: 100px;" @click="editPasswordModal = true">新增</Button>
                                            <Button type="success" style="width: 100px;"  @click="updPasswordModal = true">修改</Button>
                                            <Button type="error" style="width: 100px;"  @click="saveEdit">删除</Button>
                                        </div> -->
                                        <Table border :columns="InternetTit01" :data="InternetData01" style="margin-left:5px;" ></Table>
                                        <Page class="page-position" :current="pageIndex" :total="totalItemCount" show-total :page-size='pageSize'></Page>
                                    </Tab-pane>
                                </Tabs>
                            </div>
                                <!-- <div  class="bb-box" style="margin-bottom: 10px;text-align: center;">
                                    <Button type="primary" size="large" >设备</Button>
                                    <Button type="primary" size="large" >数据包</Button>
                                </div>
                                <Table border :columns="InternetTit" :data="InternetData"></Table>
                                <Page class="page-position" :current="pageIndex" :total="totalItemCount" show-total :page-size='pageSize'></Page> -->
                            </Col>
                        </Row>
                    </Card>
                </Col>
                 <Col span="12">
                    <Card style="width:calc(100% - 15px);height: 600px;margin-left: 15px;">
                        <p slot="title">
                            设备信息
                        </p>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <!-- <div style="border-bottom: 1px solid #ccc;margin-bottom: 5px;">设备信息</div> -->
                                <Form  class="d-form"
                                    ref="userForm"
                                    :model="userForm" 
                                    :label-width="150" 
                                    label-position="right"
                                    :rules="inforValidate"
                                >
                                    <FormItem label="ID：" >
                                        32
                                    </FormItem>
                                     <FormItem label="名称：" >
                                        水位监测设备1
                                    </FormItem>
                                    <FormItem label="采集周期：" >
                                        33 秒
                                    </FormItem>
                                </Form>
                                <!-- <div style="margin-bottom: 10px;text-align: center;">
                                    <Button type="primary" size="large" >变量启用</Button>
                                    <Button type="primary" size="large" >变量停用</Button>
                                </div> -->
                            </Col>
                        </Row>
                        <div style="border-bottom: 1px solid #ccc;margin-bottom: 15px;"></div>
                        <Row style="margin-bottom: 10px;">
                            <Col span="24">
                                <Table border :columns="InternetTit2" :data="InternetData2"></Table>
                                <Page class="page-position" :current="pageIndex" :total="totalItemCount" show-total :page-size='pageSize'></Page>
                            </Col>
                        </Row>
                    </Card>
                </Col>
            </Row>
            
        </Card>
    </div>
</template>

<script>

import {InternetData, InternetTit} from '../datas/tableData.js';
export default {
    name: '',
    data () {
        return {
            search_status: '',
            InternetTit: [{
                key:'name',
                title: '设备名称'
            }],
            InternetData: [{
                name: '设备名称1'
            }],
            InternetTit01: [{
                key:'name',
                title: '数据包名称'
            }],
            InternetData01: [{
                name: '数据包名称1'
            }],
            InternetTit2: [
            {
                title: '序号',
                type: 'index',
                width: 65,
                align: 'center'
            },{
                key:'name',
                title: '变量名称'
            },{
                key:'txt',
                title: '变量描述'
            },{
                key:'txt1',
                title: '映射采集变量',
                width: 155
            },{
                title: '操作',
                key: 'Operation',
                width: 65,
                align: 'center',
                render: (h, params) => {
                    return h('div', [
                        h('Button', {
                            props: {
                            type: 'primary',
                            size: 'small'
                            },
                            style: {
                            marginRight: '15px'
                            },
                            on: {
                            click: () => {
                                this.$router.push({
                                    name: 'configure-map'
                                })
                            }
                        }
                        }, '映射')
                        ]);
                    }
                }
            ],
            InternetData2: [{
                name: '变量1',
                txt: '变量描述',
                txt1: 'IOServer变量'
            }],
            pageIndex: 1,
            totalItemCount: 0,
            pageSize: 2,
            searchList: [{
                title: 'XXXX厂',
                expand: true,
                children: [
                    {
                        title: '污水处理区2',
                        expand: true,
                        children: [
                            {
                                title: '转速组1'
                            },
                            {
                                title: '转速组2'
                            }
                        ]
                    },
                ]
            }]
        };
    },
    mounted () {
        this.totalItemCount =   this.InternetData.length
    }
};
</script>
